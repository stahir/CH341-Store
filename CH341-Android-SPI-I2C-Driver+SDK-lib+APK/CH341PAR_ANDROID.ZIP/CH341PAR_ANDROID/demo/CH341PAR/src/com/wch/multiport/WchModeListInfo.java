package com.wch.multiport;

public class WchModeListInfo {
	 static String[] TITLES = {
	        "Information",
	        "EppTest",
	        "MemTest",
	        "IICTest",
	        "FlashTest"
	    };
	 
	 
	 static String[] DIALOGUE = {
	        "Device Information",
	        "EPP Function",
	        "MEM Function",
	        "IIC Function",
	        "FLASH Function"        
	    };
}
