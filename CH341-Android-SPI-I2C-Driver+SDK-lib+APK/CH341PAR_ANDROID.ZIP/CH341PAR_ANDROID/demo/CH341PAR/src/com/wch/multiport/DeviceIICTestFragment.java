package com.wch.multiport;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

@SuppressLint("ValidFragment")
public class DeviceIICTestFragment extends Fragment {
	private static final String TAG = "DeviceIICTestFragment";
	static Context DeviceIICTestContext;
	MultiPortManager multiport;
	EditText iic_readText, iic_writeText;
	EditText iic_DataLen0, iic_DataAddr0, iic_DataLen1, iic_DataAddr1;
	Spinner iic_DevSelection;
	Button iic_WriteBtn, iic_ReadBtn;
	
	String iic_devname;
	int iic_Selection;
	
	MyOperator operator;
	
	// Empty Constructor
	public DeviceIICTestFragment()
	{
	}
	
	/* Constructor */
	public DeviceIICTestFragment(Context parentContext , MultiPortManager MultiPortContext)
	{
		DeviceIICTestContext = parentContext;
		multiport = MultiPortContext;
	}
	
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState)
	{
		if(container == null) {
			return null;
		}
		View iicView = inflater.inflate(R.layout.iic_layout, container, false);
		
		iic_readText = (EditText) iicView.findViewById(R.id.iic_ReadValues);
		iic_writeText = (EditText) iicView.findViewById(R.id.iic_WriteValues);
		iic_DataLen0 = (EditText) iicView.findViewById(R.id.iic_DataLen0);
		iic_DataLen1 = (EditText) iicView.findViewById(R.id.iic_DataLen1);
		iic_DataAddr0 = (EditText) iicView.findViewById(R.id.iic_DataAddr0);
		iic_DataAddr1 = (EditText) iicView.findViewById(R.id.iic_DataAddr1);
		
		iic_ReadBtn = (Button) iicView.findViewById(R.id.iic_ReadButton);
		iic_WriteBtn = (Button) iicView.findViewById(R.id.iic_WriteButton);
		iic_DevSelection = (Spinner) iicView.findViewById(R.id.iic_DevName);
		
		ArrayAdapter<CharSequence> typeAdapter = ArrayAdapter.createFromResource(getActivity(), R.array.eeprom_type,
				R.layout.my_spinner_textview);
		typeAdapter.setDropDownViewResource(R.layout.my_spinner_textview);		
		iic_DevSelection.setAdapter(typeAdapter);
		iic_DevSelection.setGravity(0x10);
		iic_DevSelection.setSelection(0);
		
		/* set the adapter listeners for DevName */
		iic_DevSelection.setOnItemSelectedListener(new MyOnDevNameSelectedListener());
		iic_ReadBtn.setOnClickListener(new Iic_ReadDataFromDev());
		iic_WriteBtn.setOnClickListener(new Iic_WriteDataToDev());
		operator = new MyOperator();
		if(!multiport.CH341SetStream(0x81)) {
			Toast.makeText(DeviceIICTestContext, "IIC Mode Set Error", Toast.LENGTH_SHORT).show();
		}
		return iicView;
	}
	
	public class Iic_ReadDataFromDev implements View.OnClickListener
	{

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			long mLen = 0;
			long mAddr = 0;
			boolean retval;
			String mStr = null;
			byte [] Buffer = new byte[512];
			
			if(!multiport.isConnected())
				return;
			if(iic_DataLen0 != null) {
				String strLen = iic_DataLen0.getText().toString();
				if(strLen != null && strLen.length() > 0) {
					mLen = Integer.parseInt(strLen);
				}
			}
			if(iic_DataAddr0 != null) {
				String strAddr = iic_DataAddr0.getText().toString();
				if(strAddr !=null && strAddr.length() > 0) {
					mAddr = Integer.parseInt(strAddr);
				}
			}
			
			if(iic_DataLen0 != null && iic_DataAddr0 != null) {
				iic_Selection = multiport.SelectDevType(iic_devname);
				retval = multiport.CH341ReadEEPROM(iic_Selection, mAddr, mLen, Buffer);
				if(retval) {
					mStr = operator.tostringBuffer(Buffer, (int)mLen);
				} else {
					mStr = "ReadEEPROM Error";
				}
				iic_readText.setText(mStr);
			} else {
				iic_readText.setText("ȱ������ʹ������ʧ��");
			}
			
		}
		
	}
	
	public class Iic_WriteDataToDev implements View.OnClickListener
	{

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			long mLen = 0;
			long mAddr = 0;
			boolean retval;
			String mStr;
			byte [] Buffer = new byte[512];
			char [] iBuffer = new char[512];
			
			if(!multiport.isConnected())
				return;
			if(iic_DataLen1 != null) {
				String strLen = iic_DataLen1.getText().toString();
				if(strLen != null && strLen.length() > 0) {
					mLen = Integer.parseInt(strLen);
				}
			}
			
			if(iic_DataAddr1 != null) {
				String strAddr = iic_DataAddr1.getText().toString();
				if(strAddr !=null && strAddr.length() > 0) {
					mAddr = Integer.parseInt(strAddr);
				}
			}
			
			if(iic_writeText != null) {
				mStr = iic_writeText.getText().toString();
				if(mStr.length() < mLen) {
					mLen = mStr.length();
				} 
				if(mLen % 2 != 0) {
					mStr += "0";
					mLen += 1;
				}
				Buffer = operator.ToByte(mStr.toCharArray());
				for(int i = 0; i < mLen; i ++) {
					iBuffer[i] = (char)Buffer[i];
				}
			}
			
			if(iic_DataLen1 != null && iic_DataAddr1 != null) {
				iic_Selection = multiport.SelectDevType(iic_devname);
				retval = multiport.CH341WriteEEPROM(iic_Selection, mAddr, mLen, iBuffer);
				if(retval) {
					Toast.makeText(DeviceIICTestContext, "WriteEEPROM Sucess", Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(DeviceIICTestContext, "WriteEEPROM Failed", Toast.LENGTH_SHORT).show();
				}
				
			}
		}
		
	}
	
	public class MyOnDevNameSelectedListener implements OnItemSelectedListener {
		public void onItemSelected(AdapterView<?> parent, View view, int pos,
				long id) {

			iic_devname = parent.getItemAtPosition(pos).toString();
		}

		public void onNothingSelected(AdapterView<?> parent) { // Do nothing. }}
		}
	}
	
	public void onStart() {
		super.onStart();
	}
	
	public void onDestroy() {
		super.onDestroy();
	}
	
}
