package com.wch.multiport;

import android.annotation.SuppressLint;
import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

@SuppressLint("ValidFragment")
public class DeviceEPPTestFragment extends Fragment {
	private static final String TAG = "DeviceEPPTestFragment";
	static Context DeviceEPPTestContext;
	MultiPortManager multiport;
	MyOperator operator;
	private Button epp_AddrWrite, epp_AddrRead, epp_DataRead, epp_DataWrite;
	private EditText epp_DataLen, epp_AddrDataLen, epp_DataText, epp_AddrDataText;
	
	// Empty Constructor
	public DeviceEPPTestFragment()
	{
	}
	
	/* Constructor */
	public DeviceEPPTestFragment(Context parentContext , MultiPortManager MultiPortContext)
	{
		DeviceEPPTestContext = parentContext;
		multiport = MultiPortContext;
	}
	
	 public View onCreateView(LayoutInflater inflater, ViewGroup container,
             Bundle savedInstanceState) {
		 if(container == null) {
			 return null;
		 }
		 View view = inflater.inflate(R.layout.epp_layout, container, false);
		 
		 epp_DataLen = (EditText)view.findViewById(R.id.epp_datalength1);
		 epp_AddrDataLen = (EditText)view.findViewById(R.id.epp_datalength2);
		 epp_DataText = (EditText)view.findViewById(R.id.epp_data1);
		 epp_AddrDataText = (EditText)view.findViewById(R.id.epp_data2);
		 epp_AddrWrite = (Button)view.findViewById(R.id.epp_addwrite);
		 epp_AddrRead = (Button)view.findViewById(R.id.epp_addread);
		 epp_DataWrite = (Button)view.findViewById(R.id.epp_datawrite);
		 epp_DataRead = (Button)view.findViewById(R.id.epp_dataread);
			
		 epp_DataRead.setOnClickListener(new Epp_ReadDataFromDev());
		 epp_DataWrite.setOnClickListener(new Epp_WriteDataToDev());
		 epp_AddrWrite.setOnClickListener(new Epp_WriteAddrToDev());
		 epp_AddrRead.setOnClickListener(new Epp_ReadAddrFromDev());
		 operator = new MyOperator();
		 if(!multiport.CH341InitEpp()) {
			 Toast.makeText(DeviceEPPTestContext, "Init Epp Mode Error", Toast.LENGTH_LONG).show();
		 }
		 return view;
	 }
	
	 public class Epp_ReadDataFromDev implements View.OnClickListener
	 {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			int mLen = 0, returnLen = 0;
			String mStr = null;
			byte[] readBuffer = new byte[512];
			if(!multiport.isConnected())
				return;
			if(epp_DataLen != null) {
				String str = epp_DataLen.getText().toString();
				if(str != null && str.length() > 0) {
					mLen = Integer.parseInt(str);
				}
			}
			
			returnLen = multiport.CH341EppReadData(readBuffer, mLen);
			if(returnLen > 0) {
				Log.d(TAG, "returnLen is " + returnLen);
				mStr = operator.tostringBuffer(readBuffer, returnLen);
				epp_DataText.setText(mStr);
			}
		}
		 
	 }
	 
	 public class Epp_WriteDataToDev implements View.OnClickListener
	 {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			int mLen = 0;
			long iLen = 0;
			String mStr = null;
			char temp[] = new char[512];
			byte ioBuffer[] = new byte[512];
			
			if(!multiport.isConnected())
				return;
			
			if (epp_DataLen != null) {                     
				String str = epp_DataLen.getText().toString();                                      
				if (str != null && str.length() > 0) {                         
					mLen = Integer.parseInt(str);  
				} 
			}
			if(epp_DataText != null) {
				mStr = epp_DataText.getText().toString();
				if(mStr.length() >= mLen * 2) {
					mStr = mStr.substring(0, mLen * 2);
				} else if (mStr.length() % 2 != 0) {
					mStr += "0";
					mLen = mStr.length() / 2;
					epp_DataLen.setText(Integer.toString(mLen));
				} else {
					mLen = mStr.length() / 2;
					epp_DataLen.setText(Integer.toString(mLen));
				}
			
				temp = mStr.toCharArray();
				ioBuffer = operator.ToByte(temp);
			}

			if(epp_DataLen != null && epp_DataText != null) {
				iLen = multiport.CH341EppWriteData(ioBuffer, mLen);
				Log.d(TAG, "WriteData Length is " + iLen);
			} else {
				Toast.makeText(DeviceEPPTestContext, "WriteData��������", Toast.LENGTH_LONG).show();
			}
			
		}
		 
	 }
	 
	 public class Epp_WriteAddrToDev implements View.OnClickListener
	 {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			int mLen = 0;
			long iLen = 0;
			String mStr = null;
			char temp[] = new char[512];
			byte ioBuffer[] = new byte[512];
			if(!multiport.isConnected())
				return;
			
			if (epp_AddrDataLen != null) {                     
				String str = epp_AddrDataLen.getText().toString();                                      
				if (str != null && str.length() > 0) {                         
					mLen = Integer.parseInt(str);                     
				} 
			}
			
			if(epp_AddrDataText != null) {
				mStr = epp_AddrDataText.getText().toString();
				if(mStr.length() >= mLen * 2) {
					mStr = mStr.substring(0, mLen * 2);
				} else if (mStr.length() % 2 != 0) {
					mStr += "0";
					mLen = mStr.length() / 2;
					epp_AddrDataLen.setText(Integer.toString(mLen));
				} else {
					mLen = mStr.length() / 2;
					epp_AddrDataLen.setText(Integer.toString(mLen));
				}
			
				temp = mStr.toCharArray();
				ioBuffer = operator.ToByte(temp);
			}
			
			if(epp_AddrDataLen != null && epp_AddrDataText != null) {
				iLen = multiport.CH341EppWriteAddr(ioBuffer, mLen);
				Log.d(TAG, "WriteAddr Length is " + iLen);
			} else {
				Toast.makeText(DeviceEPPTestContext, "WriteAddr��������", Toast.LENGTH_LONG).show();
			}
			
		}
		 
	 }
	 
	 public class Epp_ReadAddrFromDev implements View.OnClickListener
	 {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			int mLen = 0, returnLen = 0;
			String mStr = null;
			byte[] readBuffer = new byte[512];
			if(!multiport.isConnected())
				return;
			
			if(epp_AddrDataLen != null) {
				String str = epp_AddrDataLen.getText().toString();
				if(str != null && str.length() > 0) {
					mLen = Integer.parseInt(str);
				}
			}
			
			returnLen = multiport.CH341EppReadAddr(readBuffer, mLen);
			if(returnLen > 0) {
				Log.d(TAG, "returnLen is " + returnLen);
				mStr = operator.tostringBuffer(readBuffer, mLen);
				epp_AddrDataText.setText(mStr);
			}
		}
		 
	 }
	 
	 public void onStart() {
		 super.onStart();
	 }
	 
	 public void onDestroy() {
		 super.onDestroy();
	 }
	 
}
