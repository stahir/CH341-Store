//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SerchCH341Port.rc
//
#define IDC_MYICON                      2
#define IDD_SERCHCH341PORT_DIALOG       102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_SERCHCH341PORT              107
#define IDI_SMALL                       108
#define IDC_SERCHCH341PORT              109
#define IDR_MAINFRAME                   128
#define IDD_main                        129
#define IDC_search                      1000
#define IDC_CH341PtHandleIsCH341        1000
#define IDC_show                        1001
#define IDC_namesearch                  1002
#define IDC_CH341PtNameIsCH341          1002
#define IDC_beginmonitor                1003
#define IDC_stopmonitor                 1004
#define IDC_clear                       1005
#define IDC_STATIC                      1007
#define IDC_dllver                      1008
#define IDC_sermonitor                  1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
