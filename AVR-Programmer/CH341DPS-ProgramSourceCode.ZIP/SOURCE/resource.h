//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CH341DP.rc
//
#define IDD_CH341DP_DIALOG              101
#define IDI_ICON1                       106
#define IDD_SETCON_DIALOG               111
#define IDD_AT89SX_SET                  113
#define IDD_SET                         115
#define IDC_BUTTON_OPEN                 1000
#define IDC_DOWN_PROGRESS               1001
#define IDC_BUTTON_BROWER               1002
#define IDC_STATIC_PROMPT               1003
#define IDC_MCU_MODEL                   1004
#define IDC_SET_CONFIG                  1005
#define IDC_BUTTON_DOWN                 1006
#define IDC_QUIT                        1007
#define IDC_READ_CONG                   1010
#define IDC_WRITE_CONG                  1011
#define IDC_SET_ALL                     1012
#define IDC_CLR_ALL                     1013
#define IDC_CLOSE                       1014
#define IDC_CHECK_BLOCk12               1016
#define IDC_CHECK_BLOCk11               1017
#define IDC_CHECK_BLOCk02               1018
#define IDC_CHECK_BLOCk01               1019
#define IDC_CHECK_LOCK2                 1020
#define IDC_CHECK_LOCK1                 1021
#define IDC_CHECK_RSTD                  1022
#define IDC_CHECK_WDTON                 1023
#define IDC_CHECK_SPIEN                 1024
#define IDC_CHECK_CKOPT                 1025
#define IDC_CHECK_EESAVE                1026
#define IDC_CHECK_BOOTSZ1               1027
#define IDC_CHECK_BOOTSZ0               1028
#define IDC_CHECK_BOOTRST               1029
#define IDC_EXPAND_SET2                 1030
#define IDC_CHECK_BODLEVEL              1031
#define IDC_CHECK1                      1031
#define IDC_EPRAM                       1031
#define IDC_CHECK_BODEN                 1032
#define IDC_CHECK_SUT1                  1033
#define IDC_CHECK_SUT0                  1034
#define IDC_CHECK_CKSEL3                1035
#define IDC_BUTTON1                     1035
#define IDC_CLRDATA                     1035
#define IDC_RUNING                      1035
#define IDC_CHECK_CKSEL2                1036
#define IDC_BUTTON2                     1036
#define IDC_CHECK_CKSEL1                1037
#define IDC_BUTTON3                     1037
#define IDC_CHECK_CKSEL0                1038
#define IDC_RADIO1                      1038
#define IDC_CHECK_M103C                 1039
#define IDC_RADIO2                      1039
#define IDC_CHECK_WDTON1                1040
#define IDC_RADIO3                      1040
#define IDC_RADIO4                      1041
#define IDC_SET_SPI                     1042
#define IDC_CMD_HELP                    1043

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        118
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1045
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
